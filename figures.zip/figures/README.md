# Research Figures

Selected figures extracted from the 2024 Honours research submission:

**Dental replacement in Gorgonopsia (Therapsida) studied using X-ray microtomography: implications for the ancestral theriodont dental replacement pattern.**

## Figure index

- `figure_01_measurement_diagram.png` — Figure 1: Cranial and dental measurement diagram.
- `figure_02_BP-1-155_CT_slice.png` — Figure 2: Virtual horizontal section through the anterior dentition of BP/1/155.
- `figure_03_BP-1-155_dental_reconstruction_panel_A.png` and `..._panel_B.png` — Figure 3: Three-dimensional rendering of the dentition of BP/1/155.
- `figure_04_AM-3752_dental_CT_slices_panel_A.png` and `..._panel_B.png` — Figure 4: Virtual horizontal sections through the anterior dentition of AM 3752.
- `figure_05_BP-1-216_dental_CT_slice_panel_A.png` and `..._panel_B.png` — Figure 5: Virtual horizontal sections through the anterior dentition of BP/1/216.
- `figure_06_BP-1-673_CT_slice.png` — Figure 6: Virtual horizontal section through the anterior dentition of BP/1/673.
- `figure_07_BP-1-673_dental_reconstruction_panel_A.png` and `..._panel_B.png` — Figure 7: Three-dimensional rendering of the dentition of BP/1/673.
- `figure_08_BP-1-709_CT_slice.png` — Figure 8: Virtual horizontal section through the anterior dentition of BP/1/709.
- `figure_09_BP-1-709_dental_reconstruction.png` — Figure 9: Three-dimensional rendering of the dentition of BP/1/709.
- `figure_10_BP-1-575_CT_slice_panel_A.png` and `..._panel_B.png` — Figure 10: Virtual horizontal section through the anterior dentition of BP/1/575.

## Notes

- Images are extracted from the original Honours report; they have not been recreated or scientifically altered.
- Panel images belonging to the same numbered figure are kept as separate files to preserve the original image quality and layout.
- The measurement diagram is identified in the report as modified from Gebauer (2007, figure 25); retain that attribution when reusing it.
- These are selected embedded figures, not the original CT scan datasets or raw segmentation files.
- Please check relevant university, supervisor and specimen-image permissions before making the repository public.
